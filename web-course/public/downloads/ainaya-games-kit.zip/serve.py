from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

SimpleHTTPRequestHandler.extensions_map['.mjs'] = 'text/javascript'
handler = partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).resolve().parent))
print('AINARIUM game: http://127.0.0.1:8893/', flush=True)
ThreadingHTTPServer(('127.0.0.1', 8893), handler).serve_forever()
