from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

class PreviewHandler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, '.mjs': 'text/javascript'}

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

root = Path(__file__).resolve().parent
print('AINARIUM creative preview: http://127.0.0.1:8895/', flush=True)
ThreadingHTTPServer(('127.0.0.1', 8895), partial(PreviewHandler, directory=str(root))).serve_forever()
